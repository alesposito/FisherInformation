% Fisher Information - numerical
% This code is based on the file 'crlb_main.m' distributed by the
% figshare.com repository at the following link
% https://figshare.com/articles/Cram_r-Rao_lower_bond_CRLB_on_lifetime_estimates/8332733
% with a CC BY 4.0 licence
% The authors of the original code published the following paper,
% describing the numerical evaluation performed:
% "Cram�r-Rao analysis of lifetime estimations in time-resolved fluorescence
% microscopy" by Dorian Bouchet, Valentina Krachmalnicoff, and Ignacio
% Izeddin, published in Optics Express 27(15):21239-21252 in 2019

% init workspace
clear
clc
%close all


% Init numerical simulation
% for details, please read crlb_main.m and supporting examples provided by
% Bouchet et al.
% Briefly, the following array [N1 G1 Nb N2 G2] defines the type of model for
% which the Fisher information is computed. Ones flags parameters that have
% to be fitted, zeros flags parameters that are assumed to be known. For
% our purpuses, we assume that we need to fit just the fractional
% contribution of the first (short / FRET-related) decay time relative to a
% known (non-FRET) decay. G1 and G2 are the inverse of the fluorescence
% lifetimes, G2= 1/tau0, and G1 = 1/(tau0(1-E)). N1 and N2 are the abolute
% number of photon counts and Nb are the number of background photons

T       = 12.5;  % ns - laser period
n_bins  = 256;   % number of bins in a TCSPC histogram
E_max   = 0.99;  % max FRET efficiency
E_steps = 128;   % number of steps to evaluate differetn FRET efficiencies
NR      = [0.1 0.5 10];    % ratios N1/N2 for which the FI should be avaluated
bIRF    = 0;     % Use Dirac (0) or  finite IRF (qirf, provided by Bouchet et al.)  
bBck    = 0;     % Fit uncorrelated background
Nb      = 0;     % Number of photons in the uncorrelated background
N2      = 1000;             % the absolute number of photons is irrelevant for these simulations. The N1/N2 is important and here we lock N2 to 1000
TAU     = [1 3 10];       % fluorescence lifetime in the absence of FRET 

MODEL   = [1 1 bBck 0 0];


tn = length(TAU);
rn = length(NR);

% assign values to the original code as defined by Bouchet et al.
res     = T/n_bins; % resolution of the aquisition board 
n_meas  = n_bins;   % number of data points
np      = E_steps;          % number of points between fv and lv

load('irf.mat'); % qirf is the IRF


nt      = zeros(np,rn,tn); % store information about total photon counts
vec     = zeros(np,rn,tn); % store information about lifetime variation 
crlb    = zeros(np,rn,tn); % store information about Cramer-Rao lower bound

for ti=1:tn
    G2      = 1/TAU(ti);   % second decay rate of 1 ns-1

    fv      = TAU(ti)*(1-E_max);   % first value of the lifetime 
    lv      = TAU(ti);             % last value of the lifetime 
    
    for ri=1:rn

        N1 = N2*NR(ri);

        for ii=1:np 

            vec(ii,ri,ti) = fv*(lv/fv)^((ii-1)/(np-1));
            G1=1/vec(ii,ri,ti);

            parameters = crlb_parameters(N1,G1,res,n_meas,Nb,N2,G2); % computes the dimensionless parameters

            if bIRF
                [coeff,~]=crlb_coefficients(MODEL,parameters,'IRF',qirf); % computes the coefficients needed to compute the information matrix
            else
                [coeff,~]=crlb_coefficients(MODEL,parameters); % computes the coefficients needed to compute the information matrix
            end

            crlb(ii,ri,ti) = crlb_fisher(MODEL,N1,coeff);

            nt(ii,ri,ti) = N1+N2;
            
            % convert errors on lifetimes to errors on E
            EM(ii,ri,ti) = 1-vec(ii,ri,ti)/TAU(ti); % FRET efficiency
            SD(ii,ri,ti) = crlb(ii,ri,ti)/TAU(ti);  % standard deviation
            SN(ii,ri,ti) = SD(ii,ri,ti)*sqrt(nt(ii,ri,ti)); % normalized sd
        end

    end
end

%%

figure
for ti=1:tn

    
    plot(EM(:,:,ti),SN(:,:,ti),'color',[(ti-1)/(tn-1) 0 1-(ti-1)/(tn-1)])
    hold on
    set(gca,'ylim',[0.1 100],'yscale','log')
    
end

axis square
xlabel('FRET efficiency')
ylabel('normalized standard deviation')




