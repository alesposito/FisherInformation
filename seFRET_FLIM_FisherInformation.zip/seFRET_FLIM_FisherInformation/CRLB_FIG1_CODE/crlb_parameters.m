function parameters = crlb_parameters(N1,G1,res,n_meas,Nb,N2,G2)

% Input: experimental parameters
% Output: dimensionless parameters


T=res*n_meas;
parameters=zeros(7,1);
parameters(1,1)=N1;
parameters(2,1)=n_meas;
parameters(3,1)=1/(G1*res); % k
parameters(4,1)=G1*T; % r
parameters(5,1)=Nb/N1; % beta
parameters(6,1)=N2/N1; % eta
parameters(7,1)=G2/G1; % gamma


    


end

