% =========================================================================
%
% This MATLAB code compute the Cramer-Rao lower bound (CRLB) on the decay rate estimates. 
%
%

clear
close all
clc

% In the following, we will use the following definitions:
% - N1: number of photons expected in the first decay 
% - G1: first decay rate (we will calculate the CRLB on this parameter)
% - Nb: number of expected background photons
% - N2: number of photons expected in the second decay 
% - G2: second decay rate

% All of these parameters may not be needed to model the data. To allow for
% this possibility, we represent the model of interest by a variable named
% MODEL, which is vector filled with 0 and 1. The length of this vector 
% encodes the number of parameters in the model, and the digit encodes 
% whether this parameter is to be estimated from the data or not (0: not to
% be estimated, 1: to be estimated).

% The models that can be studied are the following:
% - mono-exponential model with no background noise: two parameters (N1,G1)
% - mono-exponential model with background noise: three parameters (N1,G1,Nb)
% - bi-exponential model with no background noise: four parameters (N1,G1,N2,G2)
% - bi-exponential model with background noise: five parameters (N1,G1,Nb,N2,G2)



% =========================================================================
%
% Example 1: 
% Let us consider the bi-exponential model with no background noise. This
% is the 4-parameter model (N1,G1,N2,G2). If all the parameters are unknown, 
% then MODEL=[1 1 1 1]. In contrast, if the number of photons and the decay
% rate associated with the second decay are not to be estiated from the
% data (we assume that their value is known), then MODEL=[1 1 0 0]. For 
% this exemple, we will study this latter case.
% 

MODEL=[1 1 0 0];


% We now give the value of the input parameters

N1=350; % 1000 photons in the first decay
res=12.5/128; % resolution of the aquisition board 16 ps
n_meas=128; % number of data points if the repetition rate of the laser is 80 MHz
Nb=0; % does not appear in the model of interest
N2=1000; % 1000 photons in the second decay
G2=1/2.5; % second decay rate of 1 ns-1
load('irf.mat'); % qirf is the IRF


% Now it is time to compute the CRLB on the standard error on the
% lifetime estimates as a function of one parameter of interest. For this
% example, we want to study the CRLB as a function of the lifetime to be
% estimated.

fv=0.02; % first value of the lifetime (20 ps)
lv=20; % last value of the lifetime (20 ns)
np=100; % number of points between fv and lv

vec=zeros(np,2);
crlb=zeros(np,2);

for ii=1:np 
    
    vec(ii,1) = fv*(lv/fv)^((ii-1)/(np-1));   
    G1=1/vec(ii,1); % the lifetime is the inverse of the decay rate
    
    parameters = crlb_parameters(N1,G1,res,n_meas,Nb,N2,G2); % computes the dimensionless parameters
    
    [coeff,~]=crlb_coefficients(MODEL,parameters,'IRF',qirf); % computes the coefficients needed to compute the information matrix
    % if not specified, the IRF is assumed to be a Dirac delta function
 
    crlb(ii,1) = crlb_fisher(MODEL,N1,coeff); % returns the value of the crlb
        
% % You may uncomment the following to visualise the considered decay histogram    
%     figure
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,1),'Color',[0 0 1])
%     hold on
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,4),'Color',[0 0.7 0])
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,3),'Color',[1 0 0])
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,6),'k')
%     legend('1st exponential','2nd exponential','noise','total')
%     xlabel('Delay (ns)')
%     ylabel('Itensity (counts)')
%     pause
%     close  
    
end


clearvars -except vec crlb


% =========================================================================
%
% Example 2: 
% Let us consider the mono-exponential model with background noise. This
% is the 3-parameter model (N1,G1,Nb). If all the parameters are unknown, 
% then MODEL=[1 1 1]. In contrast, if the number of photons associated with 
% the noise is not to be estimated from the data (we assume that this value
% is known), then MODEL=[1 1 0]. For this exemple, we will study this 
% latter case.
% 

MODEL=[1 1 0];


% We now give the value of the input parameters

N1=1000; % 1000 photons in the first decay
res=12.5/128; % resolution of the aquisition board 16 ps
n_meas=128; % number of data points if the repetition rate of the laser is 80 MHz
Nb=1000; % 1000 photons of background noise
N2=0; % does not appear in the model of interest
G2=0; % does not appear in the model of interest
load('irf.mat'); % qirf is the IRF
qb=ones(n_meas,1)/n_meas; % uniform background noise 
%load('background') % alternatively, you can use experimentally measured background


% Now it is time to compute the CRLB on the standard error on the
% lifetime estimates as a function of one parameter of interest. For this
% example, as in the first one, we want to study the CRLB as a function of the lifetime to be
% estimated.

fv=0.02; % first value of the lifetime (20 ps)
lv=20; % last value of the lifetime (20 ns)
np=100; % number of points between fv and lv

for ii=1:np 
    
    vec(ii,2) = fv*(lv/fv)^((ii-1)/(np-1));   
    G1=1/vec(ii,2); % the lifetime is the inverse of the decay rate
    
    parameters = crlb_parameters(N1,G1,res,n_meas,Nb,N2,G2); % computes the dimensionless parameters
    
    [coeff,~]=crlb_coefficients(MODEL,parameters,'IRF',qirf,'background',qb); % computes the coefficients needed to compute the information matrix
    % if not specified, the IRF is assumed to be a Dirac delta function
    % if not specified, the background is assumed to be uniform

    crlb(ii,2) = crlb_fisher(MODEL,N1,coeff); % returns the value of the crlb
    
% % You may uncomment the following to visualise the considered decay histogram  
%     figure
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,1),'Color',[0 0 1])
%     hold on
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,4),'Color',[0 0.7 0])
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,3),'Color',[1 0 0])
%     plot((res/2:res:res*n_meas-res/2),N1*coeff(:,6),'k')
%     legend('1st exponential','2nd exponential','noise','total')
%     xlabel('Delay (ns)')
%     ylabel('Itensity (counts)')
%     pause
%     close
    
end



% =========================================================================
%
% You can finally plot your results, here, the CRLB as a function of the
% lifetime to be estimated, in the two different situations considered
% here (exponential noise and uniform noise)


figure
semilogx(vec(:,1),crlb(:,1),'Color',[0 0 1],'LineWidth',2)
hold on
plot(vec(:,2),crlb(:,2),'Color',[0 0.7 0],'LineWidth',2)
plot(vec(:,1),ones(np,1)/sqrt(N1),'Color',[1 0 0],'LineWidth',2)
xlabel('\tau (ns)')
ylabel('\sigma_{\tau}/\tau')
ax=gca;
ax.XLim=[fv lv];
ax.YLim=[0 0.25];
legend('Exponential noise (\tau_2=1 ns)','Uniform noise','N^{-1/2}','Location','best')



