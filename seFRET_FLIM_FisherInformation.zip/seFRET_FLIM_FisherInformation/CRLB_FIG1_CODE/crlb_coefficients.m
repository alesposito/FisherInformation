function [coeff,irf_test] = crlb_coefficients(Tlogic,parameters,varargin)




% Parameters 

Nb_param=length(Tlogic);
nb=parameters(2);
k=parameters(3);
r=parameters(4);
beta=parameters(5);
alpha=parameters(6);
gamma=parameters(7);
tol=1d-5;


u=0:1/k:r; % u(1) to u(n+1)


% Exponential decays

index_irf = find(strcmp(varargin,'IRF'));
if isempty(index_irf) % ideal IRF
    irf_test=0;
    J1=zeros(nb,1);
    K1=zeros(nb,1);
    for ii=1:nb
        J1(ii)=(exp(-u(ii))-exp(-u(ii+1)))/(1-exp(-r));
        K1(ii)=((u(ii+1))*exp(-u(ii+1))-(u(ii))*exp(-u(ii)))/(1-exp(-r))+(exp(-u(ii+1))-exp(-u(ii)))*(r*exp(-r))/(1-exp(-r))^2;
    end
    if (Nb_param==4) || (Nb_param==5)
        J2=zeros(nb,1);
        K2=zeros(nb,1);
        for ii=1:nb
            J2(ii)=(exp(-gamma*u(ii))-exp(-gamma*u(ii+1)))/(1-exp(-gamma*r));
            K2(ii)=((gamma*u(ii+1))*exp(-gamma*u(ii+1))-(gamma*u(ii))*exp(-gamma*u(ii)))/(1-exp(-gamma*r))+(exp(-gamma*u(ii+1))-exp(-gamma*u(ii)))*(gamma*r*exp(-gamma*r))/(1-exp(-gamma*r))^2;
        end
    end
else % actual IRF
    irf_test=1;
    qirf=varargin{index_irf+1};
    qirf=qirf/sum(qirf);
    u_exp=(0:1/k:max(-log(tol),r))';
    nb_exp=(length(u_exp))-1;
    J1=zeros(nb_exp,1);
    K1=zeros(nb_exp,1);
    for ii=1:nb_exp
        J1(ii)=(exp(-u_exp(ii))-exp(-u_exp(ii+1)));
        K1(ii)=((u_exp(ii+1))*exp(-u_exp(ii+1))-(u_exp(ii))*exp(-u_exp(ii)));
    end
    J1_c=conv(qirf,J1);
    K1_c=conv(qirf,K1);
    J1=zeros(nb,1);
    K1=zeros(nb,1);
    for ii=1:length(J1_c)
        J1(mod(ii-1,nb)+1)=J1_c(ii)+J1(mod(ii-1,nb)+1);
        K1(mod(ii-1,nb)+1)=K1_c(ii)+K1(mod(ii-1,nb)+1);
    end
    if (Nb_param==4) || (Nb_param==5)
        u_exp2=(0:1/k:max(-log(tol)/gamma,r))';
        nb_exp2=(length(u_exp2))-1;
        J2=zeros(nb_exp2,1);
        K2=zeros(nb_exp2,1);
        for ii=1:nb_exp2
            J2(ii)=(exp(-gamma*u_exp2(ii))-exp(-gamma*u_exp2(ii+1)));
            K2(ii)=((gamma*u_exp2(ii+1))*exp(-gamma*u_exp2(ii+1))-(gamma*u_exp2(ii))*exp(-gamma*u_exp2(ii)));
        end
        J2_c=conv(qirf,J2);
        K2_c=conv(qirf,K2);
        J2=zeros(nb,1);
        K2=zeros(nb,1);
        for ii=1:length(J2_c)
            J2(mod(ii-1,nb)+1)=J2_c(ii)+J2(mod(ii-1,nb)+1);
            K2(mod(ii-1,nb)+1)=K2_c(ii)+K2(mod(ii-1,nb)+1);
        end
    end
    
end



% Handles background

if (Nb_param==3) || (Nb_param==5)
    index_background = find(strcmp(varargin,'background'));
    if isempty(index_background)
        JB=ones(nb,1)/nb;
    else     
        JB=varargin{index_background+1};
        JB=JB/sum(JB);
    end    
end


% Save the coefficients

coeff=zeros(nb,6);
coeff(:,1)=J1;
coeff(:,2)=K1;

if Nb_param==2 
   coeff(:,6)=J1;
elseif Nb_param==3
   coeff(:,3)=JB;
   coeff(:,6)=J1+beta*JB;
elseif Nb_param==4
   coeff(:,4)=J2;
   coeff(:,5)=K2;
   coeff(:,6)=J1+alpha*J2;
else
   coeff(:,3)=JB;
   coeff(:,4)=J2;
   coeff(:,5)=K2;
   coeff(:,6)=J1+alpha*J2+beta*JB;
end


end

