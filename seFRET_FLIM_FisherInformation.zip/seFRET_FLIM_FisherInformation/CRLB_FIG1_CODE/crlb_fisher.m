function [CRLB,I] = crlb_fisher(Tlogic,N,coeff)


Nb_param=length(Tlogic);


J1=coeff(:,1);
K1=coeff(:,2);
JB=coeff(:,3);
J2=coeff(:,4);
K2=coeff(:,5);
f=coeff(:,6);


% Calculate the full information matrix


I=zeros(Nb_param,Nb_param);

I(1,1)=sum(J1.^2./f);
I(2,2)=sum(K1.^2./f);
I(1,2)=sum(J1.*K1./f);
I(2,1)=I(1,2);

if (Nb_param==3) || (Nb_param==5)
I(3,3)=sum(JB.^2./f);
I(1,3)=sum(J1.*JB./f);
I(3,1)=I(1,3);
I(2,3)=sum(K1.*JB./f);
I(3,2)=I(2,3);
end

if Nb_param==4 
I(3,3)=sum(J2.^2./f);
I(1,3)=sum(J1.*J2./f);
I(3,1)=I(1,3);
I(2,3)=sum(K1.*J2./f);
I(3,2)=I(2,3);

I(4,4)=sum(K2.^2./f);
I(1,4)=sum(J1.*K2./f);
I(4,1)=I(1,4);
I(2,4)=sum(K1.*K2./f);
I(4,2)=I(2,4);
I(3,4)=sum(J2.*K2./f);
I(4,3)=I(3,4);
end

if Nb_param==5
    
I(4,4)=sum(J2.^2./f);
I(1,4)=sum(J1.*J2./f);
I(4,1)=I(1,4);
I(2,4)=sum(K1.*J2./f);
I(4,2)=I(2,4);
I(3,4)=sum(JB.*J2./f);
I(4,3)=I(3,4);

I(5,5)=sum(K2.^2./f);
I(1,5)=sum(J1.*K2./f);
I(5,1)=I(1,5);
I(2,5)=sum(K1.*K2./f);
I(5,2)=I(2,5);
I(3,5)=sum(JB.*K2./f);
I(5,3)=I(3,5);
I(4,5)=sum(J2.*K2./f);
I(5,4)=I(4,5);
end


% Remove coefficients if they are not estimated from the data

for ii=Nb_param:-1:1
    if Tlogic(ii)==0
        I(:,ii)=[];
        I(ii,:)=[];
    end
end
        
Y = inv(I);

if Tlogic(1)==1 && Tlogic(2)==1
    CRLB=sqrt(1/N)*sqrt(Y(2,2));
elseif Tlogic(1)==0 && Tlogic(2)==1
    CRLB=sqrt(1/N)*sqrt(Y(1,1));
else
    error('Gamma must be estimated from the data')
end


end

