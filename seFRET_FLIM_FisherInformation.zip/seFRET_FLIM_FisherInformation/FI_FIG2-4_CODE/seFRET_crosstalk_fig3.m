

close all
clear all
warning off
tic



%%%%%%%%%%%%%%%% RUN different times with following sets of parameters %%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%

    ND  = 100;      % Number of donor molecules
    NA  = 100;      % Number of acceptor molecules
    nda = 100;      % Number of interacting pairs  



bSave = 0;
base_name = 'Elder_';



% Simulation parameters
bPlot     = 0;  % Enable/disable plotting output
bRange    = 1;  % Enable/disable for cycles
bVerbose  = 1;  % Enable/disable textual output
bAA_noise = 1;  % Add noise to calibration (IAA)
E_steps   = 20; % Number of steps for energy transfer (E=0-1)     index: e
A_steps   = 1;  % Number of steps for AER (AER=0-1)               index: a
D_steps   = 1;  % Number of steps for DER (DER=0-1)               index: d
T_steps   = 1;  % number of steps for acquisition time (1-1000)   index: t

if A_steps==1 & D_steps==1 & T_steps==1
    bRange = 0;
end

if bRange
    bPlot    = 0;
    bVerbose = 1;
end

% Initialization: storage of data output
    pp  = struct('AER',[],'DER',[],'T',[],'NP',[]); % simulation parameters 
    cFm = []; % cFRET - mean
    aFm = []; % aFRET - mean
    dFm = []; % dFRET - mean
    cFs = []; % cFRET - standard deviation
    aFs = []; % aFRET - standard deviation
    dFs = []; % dFRET - standard deviation
    Nm  = []; % mean photon count
    Ns  = []; % standard deviation of photon counts
    aFr = []; % Rao-Cramer bound (estimated standard deviation) for aFRET
    dFr = []; % Rao-Cramer bound (estimated standard deviation) for dFRET 
    
% Initialization: imaging parameters
    p    = 50;     % Number of simulated pixels
    T    = 100;     % Acquisition time (ms)
    kDex = 1;      % Donor excitation rate (1/ms)
    kAex = 6.3;      % Acceptor excitation rate (1/ms)

  

% Initialization: sample parameters - spectra
    SDD = 0.52;        % Donor brightness in the donor channel (normalized to T*Kex)
    SAA = 1;        % Acceptor brightness in the acceptor channel (normalized to T*Kex)
    BAA = 0;   % Background in the acceptor channel (normalized to T*Kex)
    BDD = 0;   % Background in the donor channel (normalized to T*Kex)
    BDA = 0;   % Background in the FRET channel (normalized to T*Kex)
    AER = 0.6;      % Acceptor excitation ratio
    DER = 0.42;      % Donor emission ratio
    AER_max = 1;
    DER_max = 1;

% Initialization: computing dependent parameters

    epl = (kAex/kDex);        % correction factor for aFRET  
    eta = SDD/SAA;          % correction factor for dFRET

    fD  = nda/ND;           % fraction of interacting donors
    fA  = nda/NA;           % fraction of interacting acceptor

    
% --- START SIMULATION ---
    
    
% --- INITIALIZATIONS ---
E_r   = (0:1/(E_steps-1):1);
counter = 0;

if bRange
    if A_steps==1
        AER_r = AER;
    else
        AER_r = (0:AER_max/(A_steps-1):AER_max);
    end

    if D_steps==1
        DER_r = DER;
    else
        DER_r = (0:DER_max/(D_steps-1):DER_max);
    end

    if T_steps==1
        T_r = T;
    else
        T_r   = (1:(10000-1)/(T_steps-1):10000);
    end            

    tic;
    t0 = toc;
    hw = waitbar(0,'Processing...');
end

tot     = T_steps*A_steps*D_steps;

for t=1:T_steps
    for a=1:A_steps
        for d=1:D_steps

            % INITIALIZATIONS
            counter = counter + 1;
            
            if bRange                    
                AER = AER_r(a);
                DER = DER_r(d);
                T   = T_r(t);
                
                %CHECK
                
                %check
                %eta = 0.19/DER;
                %epl = AER*2.5
            end

            %NP  = T*kDex*(SDD*ND+BDD+BDA)+T*kAex*(NA*SAA+BAA);    % collectable photons in the absence of FRET
            
            
            for e=1:E_steps
                
                % INITIALIZATIONS
                E   = E_r(e);               
                
                % --- ESTIMATIONS ---

                CD = SDD*ND;
                CA = SAA*NA;      
                ED = fD*E;
                EA = fA*E;
                
              
                %sED = sqrt(( CD*ED*(1-ED)*(ED*(1-eta)+eta)*epl^2 + DER*CD*(1-ED)^2*epl^2*eta*(ED*(2-eta*(1+DER))+eta*(1+DER)) +AER*CA*(AER+epl)*(1-ED)^2*epl*eta^2  +BDD*epl^2*(ED*(1-DER*eta)+DER*eta)^2  +BDA*epl^2*eta^2*(1-ED)^2   +BAA*AER^2*eta^2*(1-ED)^2)/(CD^2*kDex*T*epl));
                                
                sED = BDD*(DER*eta*(1-ED)+ED)^2*CD^-2 + ...
                      BDA*(eta^2*(1-ED)^2)*CD^-2 + ...
                      BAA*(AER^2 * eta^2 * (1-ED)^2) * epl^1 * CD^-2 + ...
                      AER*(AER+1)*(CA*(1-ED)^2*eta^2)* epl^1*CD^-2 + ...
                      DER*((DER+1)*(1-ED)*eta+2*ED)*(1-ED)^2*eta*CD^-1 + ...
                      ED*(1-ED)*(ED*(1-eta)+eta)*CD^-1;

                sED = sqrt(sED/(kDex*T));
                
                %sEA = sqrt((CA*EA*(EA+epl)*epl   +DER*(1+DER)*epl^2*(CD-CA*EA*eta)   +AER*CA*epl*(AER+2*EA+epl)   +BAA*(EA+AER)^2   +BDD*epl^2*DER^2   +BDA*epl^2)/(CA^2*kDex*T*epl^2));

                sEA = BDD*CA^-2*DER^2 + ...
                      BDA*CA^-2 + ...
                      BAA*(epl*AER*EA)^2*CD^-2*epl^-1 + ...
                      DER*(DER+1)*(CD-CA*EA*eta)*CA^-2 + ...
                      AER*((1+AER)*epl+2*EA)*CA^-1 + ...
                      EA*(1+EA*epl^-1)*CA^-1;
                
                sEA = sqrt(sEA/(kDex*T));
                
                
                % Generating images...
                IDD = T*kDex*(SDD*ND*(1-fD*E)+BDD).*ones([p p]);
                IDA = T*kDex*(ND*(SAA-DER*SDD)*fD*E+epl*AER*SAA*NA+DER*SDD*ND+BDA).*ones([p p]);
                IAA = T*kAex*(NA*SAA+BAA).*ones([p p]);

                % ...adding noise
                IDD = imnoise(IDD*1E-12,'poisson')/1E-12;
                IDA = imnoise(IDA*1E-12,'poisson')/1E-12;
                if bAA_noise
                    IAA = imnoise(IAA*1E-12,'poisson')/1E-12;
                end

                 
                %beta = 1/(AER*epl+eps);                
                % computation of estimators
                cFRET = IDA-DER*IDD-AER*IAA;
                dFRET = (cFRET.*eta)./(IDD+eps+cFRET.*eta);
                aFRET = cFRET./(IAA/epl+eps);

                %NP = mean(IDA(:))+mean(IDD(:))+mean(IAA(:));
                
%                figure,hist(dFRET(:))
                
                % Output
                if bPlot
                    figure
                    nx=2;ny=3;
                    cma=max([IDD(:); IDA(:); IAA(:)]);
                    cmi=min([IDD(:); IDA(:); IAA(:)]);
                    subplot(nx,ny,1),imagesc(IDD), axis image,set(gca,'clim',[cmi cma]),title('IDD')
                    subplot(nx,ny,2),imagesc(IDA), axis image,set(gca,'clim',[cmi cma]),title('IDA')
                    subplot(nx,ny,3),imagesc(IAA), axis image,set(gca,'clim',[cmi cma]),title('IAA')
                    subplot(nx,ny,4),imagesc(cFRET), axis image,set(gca,'clim',[cmi cma]),title('cFRET')
                    subplot(nx,ny,5),imagesc(dFRET), axis image,set(gca,'clim',[0 1]),title('dFRET')
                    subplot(nx,ny,6),imagesc(dFRET), axis image,set(gca,'clim',[0 1]),title('aFRET')
                end
                
                if bVerbose
                    display(['cFRET = ' num2str(mean(cFRET(:))) '+-' num2str(std(cFRET(:))) ' (a.u.); dFRET = ' num2str(mean(dFRET(:))) '+-' num2str(std(dFRET(:))) ' (' num2str(fD*E) '); aFRET = ' num2str(mean(aFRET(:))) '+-' num2str(std(dFRET(:))) ' (' num2str(fD*E) ')'])
                    display(['predicted errors, dFRET: ' num2str(sED) '; aFRET: ' num2str(sEA) ])
                end
                
                % --- STORAGE ---
                cFm(counter,e) = mean(cFRET(:)); % cFRET - mean
                aFm(counter,e) = mean(aFRET(:)); % aFRET - mean
                dFm(counter,e) = mean(dFRET(:)); % dFRET - mean
                cFs(counter,e) =  std(cFRET(:)); % cFRET - standard deviation
                aFs(counter,e) =  std(aFRET(:)); % aFRET - standard deviation
                dFs(counter,e) =  std(dFRET(:)); % dFRET - standard deviation
                Nm(counter,e)  = mean(IDD(:)+IDA(:)+IAA(:));   % mean photon count
                %Ns(counter,e)  =  std(NPe(:));   % standard deviation of photon counts
                aFr(counter,e) = sEA;            % Rao-Cramer bound (estimated standard deviation) for aFRET
                dFr(counter,e) = sED;            % Rao-Cramer bound (estimated standard deviation) for dFRET                                 
                NP=Nm(counter, e);
                
                
                
                
            end % t/T_steps
                
            if bRange
                completed      = counter/tot;
                elapsed_time   = toc-t0;
                estimated_time = elapsed_time*(1/completed-1);

                message = ['Elapsed time: ' num2str(elapsed_time/60) 'mins; remaining: ' num2str(estimated_time/60) 'mins'];
                waitbar(completed,hw,message);
            end

            pp(counter).AER = AER;
            pp(counter).DER = DER;
            pp(counter).T = T;
            pp(counter).NP = NP;  
        end % a/A_steps
    end % d/D_steps
end % e/E_teps

if bRange,close(hw),end

%%
bLog  = 1;
bEeff = 1;
bNORM = 1;
bPOW  = 1;

if bLog
    YLIM = [0.1 100];
    YSCALE = 'log';
else
    YLIM = [0 1];
    YSCALE = 'lin';
end

if bEeff
    Ed = fD*E_r;
    Ea = fA*E_r;
else
    Ed = E_r;
    Ea = E_r;
end


if bNORM
    %NORM = 1.*(sqrt(repmat([pp.NP]',[1 E_steps]))'./((repmat(E_r,[tot 1]))'));
    %NORM = 1./sqrt(repmat([pp.NP]',[1 E_steps]))';
    %NORM = (2*(sqrt(Nm))'./((repmat(E_r,[tot 1]))'));
    NORM = (sqrt(Nm))';
else
    NORM = 1;
end
if bPOW
    POW = 1;
else
    POW = 1;
end


COL=zeros([tot 3]);
RGB_contrast = [0.1 0.1 0.1];
if T_steps>1
    COL(:,1) = reshape(repmat((0:(1-RGB_contrast(1))./(T_steps-1):1-RGB_contrast(1)),[A_steps*D_steps 1]),[tot 1]);
else
    COL(:,1) = zeros([tot 1]);
end

if A_steps>1
    COL(:,2) = repmat(reshape(repmat((0:(1-RGB_contrast(2))./(A_steps-1):1-RGB_contrast(2)),[D_steps 1]),[D_steps*A_steps 1]),[T_steps 1]);
else
    COL(:,2) = zeros([tot 1]);
end

if D_steps>1
    COL(:,3) = repmat((0:(1-RGB_contrast(3))./(D_steps-1):1-RGB_contrast(3))',[A_steps*T_steps 1]);
else
    COL(:,3) = zeros([tot 1]);
end

set_plot = ['for i=1:tot;', ...
           '   set(h(i),''Color'',COL(i,:));', ... 
           'end;', ...
           'axis square;'];
set_scale = 'set(gca,''yscale'',YSCALE,''ylim'',YLIM,''xlim'',[0 1]); hold on;';
set_scale_a = [set_scale 'plot((0:max(Ea)/10:max(Ea)),(0:max(Ea)/10:max(Ea)),''--k'')'];
set_scale_d = [set_scale 'plot((0:max(Ed)/10:max(Ed)),(0:max(Ed)/10:max(Ed)),''--k'')'];
k=1; % separability
%set_scale_a = [set_scale 'plot((0:max(Ea)/E_steps:max(Ea)),k*1,''k'')'];
%set_scale_d = [set_scale 'plot((0:max(Ea)/E_steps:max(Ea)),k*1,''k'')'];


%%

figure
uicontrol('Style', 'text','String', 'RED: intensity; GREEN: AER; BLUE: DER','Units','Normalized','Position', [0 0 1 .05]);
subplot(1,3,1)
    h = plot(Ed,dFm);
    title('dFRET')
    set(gca,'ylim',[0 1])
    eval(set_plot);
    
subplot(1,3,2)    
    h = plot(E_r,cFm);
    title('cFRET')
    eval(set_plot);
subplot(1,3,3)
    h = plot(Ea,aFm);
    title('aFRET')
    set(gca,'ylim',[0 1])
    eval(set_plot);
    
if bSave
    saveas(gcf,['est' base_name],'eps')
    saveas(gcf,['est' base_name],'fig')    
end

    
    
%%    
    
    
figure
uicontrol('Style', 'text','String', 'RED: intensity; GREEN: AER; BLUE: DER','Units','Normalized','Position', [0 0 1 .05]);
subplot(2,2,1)
    h = plot(Ed,(dFs' .* NORM).^POW);
    title('Eff, dFRET')
    eval(set_plot);
    eval(set_scale_d);
subplot(2,2,2)    
    h = plot(Ea,(aFs' .* NORM).^POW);
    title('Eff, aFRET')
    eval(set_plot);
    eval(set_scale_a);   
subplot(2,2,3)
    h = plot(Ed,(dFr' .* NORM).^POW);
    title('RC dFRET')
    eval(set_plot);
    eval(set_scale_d); 
subplot(2,2,4)    
    h = plot(Ea,(aFr' .* NORM).^POW);
    title('RC aFRET')
    eval(set_plot);
    eval(set_scale_a);  
    
    toc

    

    
%%    
figure     % F-value
POW = 1;
set_scale = 'set(gca,''yscale'',YSCALE,''ylim'',[0 10],''xlim'',[0 1]); hold on;';
set_scale_a = [set_scale 'plot((0:max(Ea)/E_steps:max(Ea)),k*1,''-'')'];
set_scale_d = [set_scale 'plot((0:max(Ea)/E_steps:max(Ea)),k*1,''-'')'];

subplot(2,2,1)
    h = plot(Ed,(dFs' .* NORM).^POW,'.');
    hold on

    
    
    
    %new_ed = (min(Ed):(max(Ed)-min(Ed))/(100*size(Ed,2)+1):max(Ed));
    %y      = spline(Ed, (dFr' .* NORM).^POW, new_ed)
    %h      = plot(new_ed, y,'-');    
    
    h      = plot(Ed, (dFr' .* NORM).^POW,'-');    
    
    
    title('Eff, dFRET')
    eval(set_plot);
    eval(set_scale_d);
subplot(2,2,2)    
    h = plot(Ea,(aFs' .* NORM).^POW,'.');
    hold on
    title('Eff, aFRET')
    eval(set_plot);
    eval(set_scale_a);   
    
%     new_ea = (min(Ea):(max(Ea)-min(Ea))/(100*size(Ea,2)+1):max(Ea));
%     y      = spline(Ea, (aFr' .* NORM).^POW, new_ea)
%     h      = plot(new_ea, y,'-');
   h      = plot(Ea, (aFr' .* NORM).^POW,'-');  
    
if bSave
    saveas(gcf,['var' base_name],'eps')
    saveas(gcf,['var' base_name],'fig')    
end

    
    
    
    
    
    
    
    
    
    
   